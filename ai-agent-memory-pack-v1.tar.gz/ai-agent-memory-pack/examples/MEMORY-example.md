# MEMORY.md - Long-Term Memory

*Last updated: 2024-01-15*

> This is your AI's permanent knowledge base. Store facts, preferences, and lessons 
> that should persist indefinitely. Update weekly or after significant events.

---

## About the User

### Josh
- **Role:** Software developer, indie hacker
- **Location:** Melbourne, Australia
- **Timezone:** AEST/AEDT (UTC+10/+11)
- **Email:** josh@example.com
- **Communication style:** Direct, appreciates brevity

### Preferences
- **Format:** Bullet points over paragraphs
- **Data:** Charts over tables for visualization
- **Detail level:** Concise but thorough
- **Commit messages:** Detailed with context
- **Theme:** Dark mode everything

### Working Hours
- Typically active: 9am - 6pm AEST
- Sometimes works late on projects
- Prefers async communication

---

## Important Dates

| Date | Event | Notes |
|------|-------|-------|
| 2024-01-25 | Q4 Report deadline | High priority |
| 2024-02-14 | Vacation starts | 2 weeks off |
| 2024-03-15 | Contract renewal | Review terms |

---

## Projects

### AuthModule (Active)
- **Stack:** Python, FastAPI, PostgreSQL
- **Hosting:** Railway
- **Repo:** github.com/josh/auth-module
- **Status:** In development
- **Notes:** OAuth2 implementation with social login

### PersonalSite (Maintenance)
- **Stack:** Next.js, Vercel
- **Domain:** joshdev.io
- **Status:** Live, occasional updates

---

## Technical Context

### Development Environment
- **OS:** macOS
- **Editor:** VS Code with Vim keybindings
- **Terminal:** iTerm2 + zsh
- **Package manager:** pnpm preferred

### Infrastructure
- **Cloud:** Railway for backend, Vercel for frontend
- **Database:** Supabase (PostgreSQL)
- **Monitoring:** None currently (TODO: set up)

---

## Lessons Learned

### OAuth Integration (2024-01-15)
**Context:** Spent 2 hours debugging redirect_uri mismatch error  
**Root cause:** Callback URL was hardcoded, didn't match Google Console  
**Lesson:** Never hardcode OAuth callback URLs. Always use environment variables.  
**Prevention:** Add URL validation on application startup to catch mismatches early.

### API Rate Limits (2024-01-10)
**Context:** External API rate limited us, broke user experience  
**Root cause:** No retry logic, immediate failure on 429 response  
**Lesson:** Always implement exponential backoff for external API calls  
**Prevention:** Create a wrapper utility that handles retries automatically

### Database Migrations (2024-01-05)
**Context:** Migration failed in production, data inconsistency  
**Root cause:** Ran migration without backing up first  
**Lesson:** Always backup before migrations, test on staging first  
**Prevention:** Add pre-migration backup step to deployment script

---

## Working Agreements

### Memory Management
- Update MEMORY.md weekly with significant learnings
- Keep daily notes for at least 7 days before archiving
- Clear NOW.md when switching major tasks
- Never store secrets in memory files

### Communication
- Proactive updates on long-running tasks
- Summarize findings before asking for decisions
- Flag blockers immediately, don't wait

### Code Standards
- Write tests for new features (coverage > 80%)
- Use conventional commits format
- PR descriptions should explain WHY, not just WHAT

---

## System Notes

### Voice/Tone for Different Contexts
- **Technical docs:** Precise, formal
- **Chat responses:** Casual, friendly
- **Error messages:** Helpful, actionable

### Known Quirks
- User prefers `const` over `let` in JavaScript
- User dislikes semicolons in JS (prettier handles it)
- Always explain the "why" behind recommendations

---

## Frequently Needed Info

### Quick References
- **Local dev URL:** http://localhost:3000
- **Staging URL:** https://staging.authmodule.dev
- **Production URL:** https://authmodule.dev

### Common Commands
```bash
# Start development
pnpm dev

# Run tests
pnpm test

# Deploy to staging
pnpm deploy:staging

# Database migration
pnpm db:migrate
```

---

## Notes

- Keep this file under 5000 words for fast loading
- Timestamp entries so you know when things might be stale
- Archive to `memory/archive/` when sections become irrelevant
- Review quarterly and prune outdated information
