# AGENTS.md - Workspace Configuration

*Your AI's home base configuration*

---

## Workspace Paths

```
workspace_root: ~/ai-workspace/         # Where everything lives
memory_path:    ~/ai-workspace/memory/  # Daily notes
```

---

## Memory Files

| File | Purpose | Load When |
|------|---------|-----------|
| `NOW.md` | Working context | Every session |
| `MEMORY.md` | Long-term memory | Every session |
| `memory/YYYY-MM-DD.md` | Daily notes | Recent days only |
| `AGENTS.md` | Workspace config | On first session |

---

## Session Protocol

### On Session Start
1. Read `NOW.md` for current working context
2. Read `MEMORY.md` for permanent knowledge
3. Check `memory/YYYY-MM-DD.md` (today + yesterday) for recent events
4. If task-specific context exists, load relevant project files

### During Session
- Log significant events to today's daily note
- Update NOW.md when context changes significantly
- Don't update MEMORY.md unless something is truly permanent

### Before Session End
- If task interrupted: write lifeboat context to NOW.md
- If task complete: clear NOW.md and summarize in daily note
- If lesson learned: note it for weekly MEMORY.md review

---

## Memory Guidelines

### What Goes Where

**NOW.md (Working Memory)**
- Current task and status
- Recent conversation context
- Temporary debugging notes
- "Where I left off" markers

**Daily Notes (Episodic Memory)**
- What happened each day
- Decisions made with reasoning
- Errors and how they were resolved
- Tomorrow's plan

**MEMORY.md (Semantic Memory)**
- User info and preferences
- Project context and history
- Lessons learned from past mistakes
- Important recurring dates

### Retention Policy

| Age | Action |
|-----|--------|
| 0-7 days | Keep full daily notes |
| 7-30 days | Keep or summarize |
| 30+ days | Extract to MEMORY.md, archive |

---

## Safety Rules

### Never Store
- Passwords or API keys
- Authentication tokens
- Credit card numbers
- Other secrets

### Ask Before
- Sending emails or messages externally
- Posting to social media
- Making purchases or financial transactions
- Deleting important files

### Safe to Do
- Read and organize workspace files
- Search the web for information
- Update memory files
- Run safe commands within workspace

---

## File Operations

### Preferred Commands
- Use `trash` instead of `rm` (recoverable)
- Use `cp -i` to avoid overwrites
- Use `git status` before commits

### Backup Reminder
- Memory files should be in git
- Commit daily notes weekly
- Push to remote regularly

---

## Multi-Agent Setup (Optional)

If using multiple AI agents:

```
~/ai-workspace/
├── MEMORY.md              # Shared knowledge
├── NOW.md                 # Primary agent's context
├── memory/                # Shared daily logs
└── agents/
    ├── agent-1/NOW.md     # Agent 1's working memory
    └── agent-2/NOW.md     # Agent 2's working memory
```

### Coordination Rules
- MEMORY.md: Append-only (don't delete others' entries)
- Daily notes: Prefix entries with agent ID
- Each agent manages their own NOW.md

---

## Customization

This is a starting point. Add:
- Project-specific sections
- Team member info
- Custom workflows
- Tool configurations

Make it work for your setup.
