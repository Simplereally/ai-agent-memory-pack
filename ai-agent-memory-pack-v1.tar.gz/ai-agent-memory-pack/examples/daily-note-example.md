# 2024-01-15 (Monday)

*Daily note for January 15, 2024*

---

## 📋 Summary

Productive day focused on OAuth debugging. Found root cause (hardcoded callback URL), 
implemented fix, and learned important lesson about environment-based configuration.

---

## ✅ Tasks Completed

- [x] Diagnosed OAuth callback failure
- [x] Identified hardcoded URL as root cause
- [x] Refactored to use environment variable
- [x] Added debug logging for future troubleshooting
- [ ] Deploy fix to production *(in progress)*
- [ ] Update documentation *(blocked on deploy)*

---

## 🧠 Decisions Made

### Use Environment Variables for All URLs
**Context:** OAuth callback was failing because localhost URL was hardcoded  
**Decision:** Refactor all URLs to use environment variables  
**Reasoning:** 
- Different environments (local, staging, prod) need different URLs
- Hardcoding creates deployment-time bugs that are hard to trace
- Environment variables are the standard pattern for this

**Trade-offs:**
- Pro: More flexible, follows 12-factor app principles
- Con: More setup required for new developers
- Con: Easy to forget to set variables

### Add URL Validation on Startup
**Context:** This bug could have been caught earlier  
**Decision:** Add validation that checks critical URLs are configured  
**Implementation:** Check env vars on app startup, fail fast if missing

---

## 📝 Lessons Learned

### Never Hardcode OAuth Callback URLs
**What happened:** Spent 2 hours debugging a "redirect_uri mismatch" error  
**Root cause:** `http://localhost:3000/callback` was hardcoded in oauth.py  
**Fix:** Use `os.getenv('OAUTH_REDIRECT_URL')` instead  
**Prevention:** 
1. Code review flag for any hardcoded URLs
2. Startup validation for required env vars
3. Add to onboarding docs

*Added to MEMORY.md: Yes*

---

## 💬 Notable Conversations

### With Josh (14:30)
- Reported OAuth login broken since yesterday
- Confirmed working last week, broke after deploy
- Mentioned vacation coming Feb 14 (2 weeks) - need to finish before

### With Josh (16:00)
- Found the issue, explained root cause
- Discussed adding monitoring for auth failures
- Agreed to document in setup guide

---

## 🔧 Technical Notes

### Files Modified Today
- `src/auth/oauth.py` - Main fix, env var refactor
- `.env.example` - Added OAUTH_REDIRECT_URL

### Debug Commands Used
```bash
# Check Railway logs
railway logs --tail

# Test OAuth flow
curl -v https://authmodule.dev/auth/google

# Check env vars on Railway
railway variables
```

### Configuration Added
```bash
# .env.example
OAUTH_REDIRECT_URL=http://localhost:3000/auth/google/callback

# Production value
OAUTH_REDIRECT_URL=https://authmodule.dev/auth/google/callback
```

---

## ⚠️ Errors Encountered

### 14:45 - OAuth redirect_uri mismatch
- **Error:** `redirect_uri_mismatch` from Google OAuth
- **Cause:** Hardcoded localhost URL in production
- **Resolution:** Refactored to use environment variable
- **Status:** ✅ Resolved (pending deploy)

### 15:30 - Railway CLI timeout
- **Error:** `railway logs` command timed out
- **Cause:** Network hiccup
- **Resolution:** Retry worked
- **Status:** ✅ Resolved

---

## 📅 Tomorrow's Plan

1. [ ] Add OAUTH_REDIRECT_URL to Railway production env
2. [ ] Deploy and verify OAuth works
3. [ ] Update setup documentation
4. [ ] Look into error monitoring solutions
5. [ ] Write tests for OAuth callback handling

---

## 🏷️ Tags

#oauth #debugging #environment-config #authmodule
