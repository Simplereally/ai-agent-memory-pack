# AI Agent Memory System: Complete Setup Guide

**Version 1.0 | 42 Pages**

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Understanding the Architecture](#2-understanding-the-architecture)
3. [Quick Start (15 Minutes)](#3-quick-start)
4. [Deep Dive: Working Memory (NOW.md)](#4-working-memory)
5. [Deep Dive: Episodic Memory (Daily Notes)](#5-episodic-memory)
6. [Deep Dive: Semantic Memory (MEMORY.md)](#6-semantic-memory)
7. [Notion Integration](#7-notion-integration)
8. [Automation Scripts](#8-automation-scripts)
9. [Prompt Engineering for Memory](#9-prompt-engineering)
10. [Model-Specific Guides](#10-model-specific-guides)
11. [Advanced Patterns](#11-advanced-patterns)
12. [Troubleshooting](#12-troubleshooting)
13. [FAQ](#13-faq)

---

## 1. Introduction

### The Problem

Every AI assistant has the same fundamental limitation: **it forgets everything when the conversation ends.**

You've probably experienced this:
- Explaining your preferences for the hundredth time
- Re-establishing context that was already discussed
- Watching your AI "assistant" act like a stranger every session

### The Solution

This template pack implements a **3-tier memory system** that gives your AI:
- **Session continuity** through working memory
- **Historical context** through daily episodic logs  
- **Permanent knowledge** through curated semantic memory

It's the same architecture used by production AI agents running 24/7 in real deployments.

### What Makes This Different

| Approach | Pros | Cons |
|----------|------|------|
| **Stuff context window** | Simple | Expensive, limited |
| **Vector databases** | Scalable | Complex infrastructure |
| **RAG systems** | Powerful | Over-engineered for most cases |
| **This system** | Human-readable, portable, works with any model | Requires minimal file management |

---

## 2. Understanding the Architecture

### The Three Tiers

Think of this like human memory:

**Tier 1: Working Memory (NOW.md)**
- Like your mental "scratchpad"
- What you're thinking about RIGHT NOW
- Disappears when the task is done
- Updated constantly, very short-lived

**Tier 2: Episodic Memory (Daily Notes)**
- Like remembering "what happened yesterday"
- Events, conversations, decisions
- Organized by date
- Fades over time, but can be recalled

**Tier 3: Semantic Memory (MEMORY.md)**
- Like knowing "Paris is the capital of France"
- Facts, preferences, learned lessons
- Permanent (until updated)
- The AI's accumulated knowledge

### Information Flow

```
[Conversation] 
    ↓
[Working Memory: NOW.md] ← Updated each session
    ↓ (at end of session)
[Episodic Memory: daily notes] ← Raw logs stored
    ↓ (weekly review)
[Semantic Memory: MEMORY.md] ← Curated insights extracted
```

### The "Lifeboat" Pattern

The key innovation is the **NOW.md lifeboat**:

When a conversation ends or gets interrupted:
1. The AI writes critical context to NOW.md
2. Next session, it loads NOW.md first
3. Session continuity is preserved

This is why we call it a "lifeboat" — it rescues context from drowning when sessions end.

---

## 3. Quick Start (15 Minutes)

### Step 1: Create Your Workspace (2 min)

Create this folder structure:

```
my-ai-workspace/
├── NOW.md                    # Working memory
├── MEMORY.md                 # Long-term memory
├── memory/                   # Daily notes folder
│   └── (dated files go here)
└── AGENTS.md                 # Optional: workspace config
```

### Step 2: Copy Example Files (3 min)

Copy the example files from this pack:
- `examples/MEMORY-example.md` → `MEMORY.md`
- `examples/NOW-example.md` → `NOW.md`
- `examples/daily-note-template.md` → `memory/2024-01-15.md`

### Step 3: Add Memory Loading to System Prompt (5 min)

Add this to your AI's system instructions:

```markdown
## Memory System

Before responding, load your memory:
1. Read NOW.md for current working context
2. Read MEMORY.md for long-term knowledge
3. Check memory/YYYY-MM-DD.md for recent activity

At the end of significant sessions:
- Update NOW.md with current working context
- Log important events to today's daily note

Your memory files are your continuity. Use them.
```

### Step 4: Test It (5 min)

1. Start a conversation with your AI
2. Tell it something to remember (a preference, a fact)
3. Ask it to update MEMORY.md
4. End the session
5. Start a new session
6. Verify it remembers

**Congratulations!** You now have a working memory system.

---

## 4. Working Memory (NOW.md)

### Purpose

NOW.md is your AI's "mental scratchpad" — the immediate context it needs for the current task or session.

### What Goes Here

- Current task or project being worked on
- Recent conversation context
- Temporary notes that won't matter tomorrow
- "Where I left off" markers

### Example NOW.md

```markdown
# NOW.md - Working Context

## Current Focus
Working on quarterly report. User wants focus on Q4 metrics.

## Recent Context
- Just finished discussing marketing budget
- User mentioned they prefer charts over tables
- Deadline: end of week

## Temporary Notes
- Report draft at ~/documents/q4-draft.md
- Need to incorporate sales data from Sarah

## Session State
- Model: Claude-3-Opus
- Started: 2024-01-15 14:30
- Last active: 2024-01-15 16:45
```

### Update Frequency

- **Update**: Every significant session transition
- **Clear**: When task is complete
- **Rebuild**: At start of new major task

### The Lifeboat Pattern in Practice

When your AI is about to lose context (session ending, context window full):

```markdown
## LIFEBOAT - Session Interrupted

Saving context for next session:

**What we were doing:**
Debugging the authentication module, specifically the OAuth callback.

**Where we left off:**
Line 247 of auth.py - the redirect_uri mismatch error

**Key discoveries so far:**
1. The callback URL in Google Console doesn't match
2. Environment variable OAUTH_REDIRECT not being read
3. Suspect: .env file not being loaded in production

**Next steps:**
1. Check production .env exists
2. Verify callback URL in Google Console
3. Add debug logging to see what redirect_uri is being used

**Files involved:**
- auth.py (main issue)
- .env (suspected cause)
- deploy.sh (might need env loading)
```

This pattern ensures the next session can pick up exactly where you left off.

---

## 5. Episodic Memory (Daily Notes)

### Purpose

Daily notes are your AI's "diary" — a raw log of what happened each day.

### File Naming

Use ISO date format: `memory/YYYY-MM-DD.md`

Examples:
- `memory/2024-01-15.md`
- `memory/2024-01-16.md`

### What Goes Here

- Summary of conversations and tasks
- Decisions made (with reasoning)
- Errors encountered and lessons learned
- Important events or discoveries

### Example Daily Note

```markdown
# 2024-01-15 (Monday)

## Summary
Productive day. Finished OAuth debugging, deployed fix to production.

## Tasks Completed
- [x] Fixed OAuth callback URL mismatch
- [x] Deployed authentication fix
- [x] Updated documentation

## Decisions Made
- **Use environment variables for all URLs** — hardcoding caused the OAuth bug
- **Add URL validation on startup** — would have caught this earlier

## Lessons Learned
- Always check production .env after deploying new environment variables
- Google Console changes can take 5 minutes to propagate

## Notable Events
- User (Josh) mentioned upcoming vacation next week
- Preference noted: prefers detailed commit messages

## Errors/Issues
- 14:32: OAuth redirect_uri mismatch (RESOLVED)
- 16:45: Rate limited by API (waited 60s, recovered)

## Tomorrow
- Set up monitoring for auth failures
- Review other hardcoded URLs
```

### Retention Policy

Recommended approach:
- **Days 1-7**: Keep full detail
- **Days 8-30**: Keep or summarize
- **Day 30+**: Extract important lessons to MEMORY.md, archive or delete

The automation scripts handle this automatically.

---

## 6. Semantic Memory (MEMORY.md)

### Purpose

MEMORY.md is your AI's permanent knowledge base — facts, preferences, and accumulated wisdom that should persist indefinitely.

### What Goes Here

- User information and preferences
- Project context and history
- Lessons learned from past mistakes
- Important dates and events
- System configuration notes

### What Doesn't Go Here

- Secrets, API keys, passwords (never!)
- Temporary task notes (use NOW.md)
- Detailed event logs (use daily notes)
- Information that will become stale quickly

### Example MEMORY.md

```markdown
# MEMORY.md - Long-Term Memory

*Last updated: 2024-01-15*

## About the User

### Josh
- Role: Software developer, indie hacker
- Timezone: Australia/Melbourne (AEST/AEDT)
- Preferred contact: Telegram
- Communication style: Direct, appreciates brevity

### Preferences
- Prefers bullet points over paragraphs
- Likes detailed commit messages
- Charts over tables for data visualization
- Dark mode everything

## Important Dates
- 2024-01-25: Project deadline (Q4 report)
- 2024-02-14: Vacation starts (2 weeks)

## Projects

### Main Project: AuthModule
- Stack: Python, FastAPI, PostgreSQL
- Deployed on: Railway
- Repo: github.com/josh/auth-module

## Lessons Learned

### OAuth Integration (2024-01-15)
**Context**: Spent 2 hours debugging redirect_uri mismatch
**Lesson**: Never hardcode OAuth callback URLs. Use environment variables.
**Prevention**: Add URL validation on application startup.

### API Rate Limits (2024-01-10)
**Context**: Got rate limited by external API, broke user experience
**Lesson**: Always implement exponential backoff
**Prevention**: Wrap all API calls in retry handler

## Working Agreements
- Update MEMORY.md weekly with significant learnings
- Keep daily notes for at least 7 days
- Clear NOW.md when switching major tasks
```

### Update Frequency

- **Weekly review**: Extract insights from daily notes
- **On significant events**: Major learnings, new user info
- **Quarterly cleanup**: Remove outdated information

---

## 7. Notion Integration

### Why Notion?

Notion provides:
- Beautiful UI for reviewing memories
- Easy sharing and collaboration
- Mobile access to your AI's memory
- Built-in search and filtering
- API for automation

### Template Overview

This pack includes three Notion databases:

1. **Daily Notes Database**
   - Properties: Date, Summary, Tags, Lessons, Status
   - Views: Calendar, Timeline, By Tag

2. **Long-term Memory Database**
   - Properties: Category, Content, Source Date, Confidence
   - Views: By Category, Recent, Searchable

3. **Working Context Page**
   - Template for NOW.md equivalent
   - Quick capture and status tracking

### Import Instructions

1. Download the Notion export ZIP from `/notion-templates/`
2. Open Notion
3. Click "Import" in the sidebar
4. Select the ZIP file
5. Choose "Import into current workspace"
6. Templates appear as new pages

### Syncing with Markdown Files

Use the `notion_sync.py` script for bidirectional sync:

```bash
# Sync Notion → Markdown files
python scripts/notion_sync.py pull

# Sync Markdown → Notion
python scripts/notion_sync.py push

# Two-way sync (merge)
python scripts/notion_sync.py sync
```

Setup requires a Notion integration token. See the script's README for configuration.

---

## 8. Automation Scripts

### Overview

Four Python scripts automate memory maintenance:

| Script | Purpose | Run Frequency |
|--------|---------|---------------|
| `memory_extractor.py` | Parse conversations → memories | After each conversation |
| `daily_summarizer.py` | Daily notes → MEMORY.md | Weekly |
| `now_generator.py` | Generate NOW.md from context | On session start |
| `notion_sync.py` | Sync files ↔ Notion | As needed |

### Installation

```bash
# Clone the scripts
cd your-ai-workspace
cp -r /path/to/ai-memory-pack/scripts ./scripts

# Install dependencies
pip install -r scripts/requirements.txt

# Configure
cp scripts/config.example.yaml scripts/config.yaml
# Edit config.yaml with your settings
```

### memory_extractor.py

Parses conversation transcripts and extracts memorable information.

```bash
# Basic usage
python scripts/memory_extractor.py conversation.txt

# With OpenAI for smarter extraction
python scripts/memory_extractor.py conversation.txt --use-ai

# Output to specific file
python scripts/memory_extractor.py conversation.txt -o memory/2024-01-15.md
```

**What it extracts:**
- Facts mentioned (names, dates, preferences)
- Decisions made
- Lessons learned
- Action items

### daily_summarizer.py

Reviews daily notes and updates MEMORY.md with lasting insights.

```bash
# Summarize last 7 days
python scripts/daily_summarizer.py --days 7

# Summarize specific date range
python scripts/daily_summarizer.py --from 2024-01-01 --to 2024-01-15

# Dry run (show what would be added)
python scripts/daily_summarizer.py --days 7 --dry-run
```

**What it does:**
1. Reads daily notes in range
2. Identifies patterns and significant learnings
3. Proposes additions to MEMORY.md
4. Optionally archives old daily notes

### now_generator.py

Generates a NOW.md file from recent context.

```bash
# Generate from recent activity
python scripts/now_generator.py

# Generate from specific sources
python scripts/now_generator.py --from memory/2024-01-15.md --from MEMORY.md

# Include current git status
python scripts/now_generator.py --include-git
```

**Useful for:**
- Session recovery after crashes
- Onboarding new AI instances
- Switching between projects

### notion_sync.py

Bidirectional sync between markdown files and Notion databases.

```bash
# Setup (one time)
python scripts/notion_sync.py setup

# Pull from Notion to local files
python scripts/notion_sync.py pull

# Push local files to Notion
python scripts/notion_sync.py push

# Full bidirectional sync
python scripts/notion_sync.py sync
```

**Configuration required:**
- Notion integration token
- Database IDs for each database
- Field mapping in config.yaml

---

## 9. Prompt Engineering for Memory

### System Prompt Templates

#### Minimal Memory Loading

```markdown
## Your Memory

You have persistent memory stored in files:
- NOW.md: Current working context
- MEMORY.md: Long-term knowledge
- memory/YYYY-MM-DD.md: Daily logs

Read these files at the start of each session. Update them as needed.
```

#### Full Memory Protocol

```markdown
## Memory System

You have a 3-tier memory system:

### Tier 1: Working Memory (NOW.md)
- Current task context and state
- Read at session start
- Update when context changes significantly
- Clear when task completes

### Tier 2: Episodic Memory (memory/YYYY-MM-DD.md)
- Daily logs of events, decisions, lessons
- Create new file each day
- Write significant events as they happen
- Review weekly for patterns

### Tier 3: Semantic Memory (MEMORY.md)
- Permanent facts, preferences, lessons
- Updated weekly from daily note review
- Contains user info, project context, learned lessons
- Never put secrets here

### Session Protocol
1. On session start: Read NOW.md, then MEMORY.md
2. During session: Log significant events to daily note
3. Before context-loss: Save critical state to NOW.md
4. Weekly: Summarize daily notes into MEMORY.md

### Write It Down
You have limited memory. If you want to remember something, WRITE IT TO A FILE.
Mental notes don't survive session restarts. Files do.
```

### Memory Loading Patterns

#### Lazy Loading
Only load what you need:
```markdown
If the user mentions a project, check MEMORY.md for project context.
If continuing from yesterday, read yesterday's daily note.
```

#### Eager Loading
Load everything upfront (uses more context):
```markdown
Before your first response, read:
1. NOW.md
2. MEMORY.md  
3. memory/YYYY-MM-DD.md (today)
4. memory/YYYY-MM-DD.md (yesterday)
```

#### Selective Loading
Best for limited context windows:
```markdown
Read NOW.md first. It tells you what else to load.
If NOW.md says "continuing project X", load X's context from MEMORY.md.
```

---

## 10. Model-Specific Guides

### Claude (Anthropic)

**Strengths:** Excellent at following memory protocols, long context window

**System prompt addition:**
```markdown
You have filesystem access via tools. Use read_file and write_file to manage your memory.
```

**Tips:**
- Claude follows memory update instructions reliably
- Use XML tags for structured memory sections
- Claude can handle large MEMORY.md files (100k context)

### GPT-4 (OpenAI)

**Strengths:** Good at extraction and summarization

**System prompt addition:**
```markdown
Use Code Interpreter to read and write your memory files.
```

**Tips:**
- GPT-4 may need reminding to update files
- Works well with the automation scripts
- Consider using the API for direct file access

### Llama / Open Source Models

**Strengths:** Local, private, no API costs

**Considerations:**
- Smaller context windows — use selective loading
- May need more explicit instructions
- Test memory update reliability

**Tips:**
- Use the automation scripts heavily
- Keep MEMORY.md concise
- Implement regular file syncs

### Multi-Model Setups

If you use different models for different tasks:

```markdown
## Memory Sharing

All models share the same memory files:
- NOW.md: Working context (any model can update)
- MEMORY.md: Long-term (update carefully, prefer appending)
- Daily notes: Each model logs its own activity

When switching models mid-task, update NOW.md with handoff context.
```

---

## 11. Advanced Patterns

### Multi-Agent Memory

When multiple AI agents share a workspace:

```
workspace/
├── MEMORY.md              # Shared long-term memory
├── NOW.md                 # Current lead agent's context
├── memory/                # Shared daily notes
└── agents/
    ├── agent-1/
    │   └── NOW.md         # Agent 1's working context
    └── agent-2/
        └── NOW.md         # Agent 2's working context
```

**Coordination rules:**
- MEMORY.md: Append-only (don't delete others' entries)
- Daily notes: Prefix entries with agent ID
- NOW.md per agent: Each agent manages their own

### Memory Hierarchies

For complex projects:

```
workspace/
├── MEMORY.md              # Personal long-term memory
├── projects/
│   ├── project-a/
│   │   ├── MEMORY.md      # Project-specific memory
│   │   └── NOW.md         # Project working context
│   └── project-b/
│       ├── MEMORY.md
│       └── NOW.md
```

### Confidence Levels

Track memory reliability:

```markdown
## Facts (High Confidence)
- User's name is Josh [confirmed directly]
- Timezone is Melbourne [confirmed directly]

## Inferences (Medium Confidence)
- User prefers morning meetings [observed pattern]
- Dislikes verbose documentation [inferred from feedback]

## Guesses (Low Confidence)
- May be interested in AI agents [mentioned once]
```

### Memory Versioning

Track memory evolution:

```markdown
## Lessons Learned

### API Rate Limiting
*Added: 2024-01-10*
*Updated: 2024-01-15*
*Confidence: High*

**Original lesson:** Implement retry logic for API calls.
**Update:** Use exponential backoff specifically, not just linear retry.
```

### Privacy Tiers

For sensitive information:

```markdown
## Privacy Notes

### Public (can mention in any context)
- Project names
- General preferences
- Technical setup

### Private (main session only)
- Personal details
- Financial information
- Health information

### Secret (never store)
- Passwords
- API keys
- Authentication tokens
```

---

## 12. Troubleshooting

### AI Not Reading Memory Files

**Symptoms:** AI acts like it has no memory, asks questions already answered

**Solutions:**
1. Check file paths in system prompt
2. Verify AI has file access permissions
3. Add explicit "read these files first" instruction
4. Test file reading with a simple command

### Memory Files Getting Too Large

**Symptoms:** Slow loading, context window overflow

**Solutions:**
1. Implement retention policy (archive old daily notes)
2. Summarize instead of appending to MEMORY.md
3. Use selective loading (not everything at once)
4. Split MEMORY.md into topic-specific files

### Conflicting Memories

**Symptoms:** AI gives inconsistent answers based on outdated info

**Solutions:**
1. Add timestamps to all memory entries
2. Mark outdated info as deprecated, not deleted
3. Use confidence levels
4. Run regular memory audits

### AI Forgets to Update Memory

**Symptoms:** Important information lost between sessions

**Solutions:**
1. Add explicit update reminders in system prompt
2. Use the automation scripts for extraction
3. End sessions with "update your memory" request
4. Implement the lifeboat pattern for interruptions

### Notion Sync Conflicts

**Symptoms:** Data loss or duplication during sync

**Solutions:**
1. Use single-direction sync (Notion as source of truth, or files as source)
2. Implement conflict resolution in config
3. Run sync less frequently
4. Review changes before applying

---

## 13. FAQ

**Q: How much does this cost to run?**
A: The core system (just files) is free. Notion is free for personal use. The AI costs depend on your model and usage.

**Q: Can I use this without Notion?**
A: Yes! The markdown files work standalone. Notion is optional for better visualization.

**Q: How often should I review MEMORY.md?**
A: Weekly is ideal. Monthly is acceptable. Less than monthly and it becomes stale.

**Q: Should I commit memory files to git?**
A: MEMORY.md and AGENTS.md: yes (no secrets). Daily notes: optional. NOW.md: no (ephemeral).

**Q: What's the maximum size for MEMORY.md?**
A: Depends on your model's context window. For Claude (100k): ~50k tokens. For GPT-4 (8k): ~4k tokens. Use selective loading for smaller windows.

**Q: Can multiple people use one memory system?**
A: Yes, but consider privacy. Use "About [Name]" sections or separate files per person.

**Q: How do I migrate from another memory system?**
A: Run the memory_extractor.py script on your existing data, then manually curate into MEMORY.md.

**Q: Do I need coding skills?**
A: Basic setup: no. Automation scripts: basic Python knowledge helps but isn't required.

---

## Conclusion

You now have everything you need to give your AI assistant persistent memory.

Start simple:
1. Create the three files (NOW.md, MEMORY.md, one daily note)
2. Add the memory loading prompt
3. Use it for a week

Then expand:
- Add Notion for better visualization
- Set up automation scripts
- Implement advanced patterns as needed

The key is consistency. Update your files regularly, and your AI will become more capable over time.

Good luck!

---

*Have questions? Found a bug? Email support@yourdomain.com*
