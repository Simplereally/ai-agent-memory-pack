#!/usr/bin/env python3
"""
memory_extractor.py - Extract memories from conversation transcripts

This script parses conversation logs and extracts:
- Facts mentioned (names, dates, preferences)
- Decisions made
- Lessons learned
- Action items

Usage:
    python memory_extractor.py conversation.txt
    python memory_extractor.py conversation.txt --use-ai
    python memory_extractor.py conversation.txt -o output.md
"""

import argparse
import re
import os
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
import json

# Optional AI extraction (requires openai package)
try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class MemoryExtractor:
    """Extract memorable information from conversation text."""
    
    def __init__(self, use_ai: bool = False, openai_key: Optional[str] = None):
        self.use_ai = use_ai and HAS_OPENAI
        if self.use_ai and openai_key:
            openai.api_key = openai_key
        elif self.use_ai:
            openai.api_key = os.getenv('OPENAI_API_KEY')
    
    def extract(self, text: str) -> Dict:
        """Extract memories from conversation text."""
        if self.use_ai:
            return self._extract_with_ai(text)
        return self._extract_with_rules(text)
    
    def _extract_with_rules(self, text: str) -> Dict:
        """Rule-based extraction (no AI required)."""
        memories = {
            'facts': [],
            'decisions': [],
            'lessons': [],
            'action_items': [],
            'dates': [],
            'preferences': []
        }
        
        lines = text.split('\n')
        
        for line in lines:
            line_lower = line.lower().strip()
            
            # Extract decisions
            if any(phrase in line_lower for phrase in [
                'decided to', 'decision:', 'we agreed', 'let\'s go with',
                'the plan is', 'will do', 'going to'
            ]):
                memories['decisions'].append(line.strip())
            
            # Extract lessons
            if any(phrase in line_lower for phrase in [
                'learned that', 'lesson:', 'mistake was', 'should have',
                'next time', 'note to self', 'remember to', 'turns out'
            ]):
                memories['lessons'].append(line.strip())
            
            # Extract action items
            if any(phrase in line_lower for phrase in [
                'todo:', 'to do:', 'action:', '- [ ]', 'need to',
                'must do', 'don\'t forget', 'reminder:'
            ]):
                memories['action_items'].append(line.strip())
            
            # Extract preferences
            if any(phrase in line_lower for phrase in [
                'prefer', 'i like', 'i don\'t like', 'favorite',
                'always use', 'never use', 'usually'
            ]):
                memories['preferences'].append(line.strip())
            
            # Extract dates
            date_patterns = [
                r'\b\d{4}-\d{2}-\d{2}\b',  # ISO date
                r'\b\d{1,2}/\d{1,2}/\d{4}\b',  # US date
                r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},? \d{4}\b'
            ]
            for pattern in date_patterns:
                matches = re.findall(pattern, line, re.IGNORECASE)
                for match in matches:
                    memories['dates'].append({
                        'date': match,
                        'context': line.strip()[:100]
                    })
            
            # Extract facts (names, emails, URLs)
            email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            emails = re.findall(email_pattern, line)
            for email in emails:
                memories['facts'].append(f"Email mentioned: {email}")
            
            url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
            urls = re.findall(url_pattern, line)
            for url in urls:
                memories['facts'].append(f"URL mentioned: {url}")
        
        # Deduplicate
        for key in memories:
            if isinstance(memories[key], list) and memories[key]:
                if isinstance(memories[key][0], str):
                    memories[key] = list(dict.fromkeys(memories[key]))
        
        return memories
    
    def _extract_with_ai(self, text: str) -> Dict:
        """AI-powered extraction using OpenAI."""
        if not HAS_OPENAI:
            print("Warning: openai package not installed. Using rule-based extraction.")
            return self._extract_with_rules(text)
        
        prompt = """Analyze this conversation and extract:
1. Facts: Specific information like names, emails, dates, preferences
2. Decisions: Choices made or agreed upon
3. Lessons: Things learned or mistakes identified
4. Action items: Tasks to do
5. Key dates: Important dates mentioned with context

Format as JSON with keys: facts, decisions, lessons, action_items, dates

Conversation:
"""
        
        try:
            response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You extract structured memories from conversations. Return valid JSON only."},
                    {"role": "user", "content": prompt + text[:8000]}  # Limit context
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            result = response.choices[0].message.content
            # Clean potential markdown code blocks
            result = re.sub(r'^```json\s*', '', result)
            result = re.sub(r'\s*```$', '', result)
            return json.loads(result)
        except Exception as e:
            print(f"AI extraction failed: {e}. Falling back to rules.")
            return self._extract_with_rules(text)
    
    def to_markdown(self, memories: Dict) -> str:
        """Convert extracted memories to markdown format."""
        today = datetime.now().strftime('%Y-%m-%d')
        lines = [f"# Memory Extraction - {today}\n"]
        
        if memories.get('facts'):
            lines.append("## Facts\n")
            for fact in memories['facts']:
                lines.append(f"- {fact}")
            lines.append("")
        
        if memories.get('decisions'):
            lines.append("## Decisions Made\n")
            for decision in memories['decisions']:
                lines.append(f"- {decision}")
            lines.append("")
        
        if memories.get('lessons'):
            lines.append("## Lessons Learned\n")
            for lesson in memories['lessons']:
                lines.append(f"- {lesson}")
            lines.append("")
        
        if memories.get('action_items'):
            lines.append("## Action Items\n")
            for item in memories['action_items']:
                lines.append(f"- [ ] {item}")
            lines.append("")
        
        if memories.get('dates'):
            lines.append("## Important Dates\n")
            for date_info in memories['dates']:
                if isinstance(date_info, dict):
                    lines.append(f"- **{date_info['date']}**: {date_info.get('context', '')}")
                else:
                    lines.append(f"- {date_info}")
            lines.append("")
        
        if memories.get('preferences'):
            lines.append("## Preferences Noted\n")
            for pref in memories['preferences']:
                lines.append(f"- {pref}")
            lines.append("")
        
        return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='Extract memories from conversation transcripts'
    )
    parser.add_argument('input', help='Input conversation file')
    parser.add_argument('-o', '--output', help='Output markdown file')
    parser.add_argument('--use-ai', action='store_true',
                        help='Use AI for smarter extraction (requires OpenAI API key)')
    parser.add_argument('--json', action='store_true',
                        help='Output as JSON instead of markdown')
    
    args = parser.parse_args()
    
    # Read input
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {args.input}")
        return 1
    
    text = input_path.read_text()
    
    # Extract
    extractor = MemoryExtractor(use_ai=args.use_ai)
    memories = extractor.extract(text)
    
    # Output
    if args.json:
        output = json.dumps(memories, indent=2)
    else:
        output = extractor.to_markdown(memories)
    
    if args.output:
        Path(args.output).write_text(output)
        print(f"Wrote memories to {args.output}")
    else:
        print(output)
    
    # Summary
    total = sum(len(v) if isinstance(v, list) else 0 for v in memories.values())
    print(f"\nExtracted {total} memories")
    
    return 0


if __name__ == '__main__':
    exit(main())
