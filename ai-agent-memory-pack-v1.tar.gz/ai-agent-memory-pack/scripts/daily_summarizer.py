#!/usr/bin/env python3
"""
daily_summarizer.py - Summarize daily notes into long-term memory

Reviews daily note files and:
- Identifies patterns and significant learnings
- Proposes additions to MEMORY.md
- Optionally archives old daily notes

Usage:
    python daily_summarizer.py --days 7
    python daily_summarizer.py --from 2024-01-01 --to 2024-01-15
    python daily_summarizer.py --days 7 --dry-run
"""

import argparse
import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional
import json

# Optional AI summarization
try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class DailySummarizer:
    """Summarize daily notes into long-term memory."""
    
    def __init__(self, memory_path: str = 'memory', use_ai: bool = False):
        self.memory_path = Path(memory_path)
        self.use_ai = use_ai and HAS_OPENAI
        if self.use_ai:
            openai.api_key = os.getenv('OPENAI_API_KEY')
    
    def find_daily_notes(self, start_date: datetime, end_date: datetime) -> List[Path]:
        """Find daily note files in date range."""
        notes = []
        current = start_date
        
        while current <= end_date:
            filename = f"{current.strftime('%Y-%m-%d')}.md"
            filepath = self.memory_path / filename
            if filepath.exists():
                notes.append(filepath)
            current += timedelta(days=1)
        
        return notes
    
    def parse_daily_note(self, filepath: Path) -> Dict:
        """Parse a daily note file into structured data."""
        content = filepath.read_text()
        
        sections = {
            'date': filepath.stem,
            'raw_content': content,
            'decisions': [],
            'lessons': [],
            'tasks_completed': [],
            'errors': [],
            'notes': []
        }
        
        current_section = 'notes'
        
        for line in content.split('\n'):
            line_lower = line.lower().strip()
            
            # Detect section headers
            if 'decision' in line_lower and line.startswith('#'):
                current_section = 'decisions'
                continue
            elif 'lesson' in line_lower and line.startswith('#'):
                current_section = 'lessons'
                continue
            elif any(x in line_lower for x in ['task', 'completed', 'done']) and line.startswith('#'):
                current_section = 'tasks_completed'
                continue
            elif 'error' in line_lower and line.startswith('#'):
                current_section = 'errors'
                continue
            
            # Extract content
            if line.strip().startswith('- [x]'):
                sections['tasks_completed'].append(line.strip()[5:].strip())
            elif line.strip().startswith('- ') and current_section in sections:
                sections[current_section].append(line.strip()[2:])
        
        return sections
    
    def summarize(self, notes: List[Dict]) -> Dict:
        """Summarize multiple daily notes into insights."""
        if self.use_ai:
            return self._summarize_with_ai(notes)
        return self._summarize_with_rules(notes)
    
    def _summarize_with_rules(self, notes: List[Dict]) -> Dict:
        """Rule-based summarization."""
        summary = {
            'period': f"{notes[0]['date']} to {notes[-1]['date']}" if notes else "N/A",
            'total_days': len(notes),
            'key_decisions': [],
            'lessons_learned': [],
            'recurring_themes': [],
            'tasks_summary': {
                'completed': 0,
                'categories': {}
            },
            'proposed_memory_additions': []
        }
        
        all_decisions = []
        all_lessons = []
        all_tasks = []
        word_freq = {}
        
        for note in notes:
            all_decisions.extend(note.get('decisions', []))
            all_lessons.extend(note.get('lessons', []))
            all_tasks.extend(note.get('tasks_completed', []))
            
            # Word frequency for themes
            content = note.get('raw_content', '')
            words = re.findall(r'\b[a-z]{4,}\b', content.lower())
            for word in words:
                if word not in ['this', 'that', 'with', 'from', 'have', 'been']:
                    word_freq[word] = word_freq.get(word, 0) + 1
        
        # Deduplicate and rank
        summary['key_decisions'] = list(dict.fromkeys(all_decisions))[:10]
        summary['lessons_learned'] = list(dict.fromkeys(all_lessons))[:10]
        summary['tasks_summary']['completed'] = len(all_tasks)
        
        # Find recurring themes (words appearing in multiple notes)
        recurring = [(word, count) for word, count in word_freq.items() 
                    if count >= len(notes) * 0.5 and count >= 3]
        recurring.sort(key=lambda x: x[1], reverse=True)
        summary['recurring_themes'] = [w for w, c in recurring[:10]]
        
        # Propose memory additions
        for lesson in all_lessons[:5]:
            summary['proposed_memory_additions'].append({
                'type': 'lesson',
                'content': lesson,
                'source': summary['period']
            })
        
        for decision in all_decisions[:5]:
            summary['proposed_memory_additions'].append({
                'type': 'decision',
                'content': decision,
                'source': summary['period']
            })
        
        return summary
    
    def _summarize_with_ai(self, notes: List[Dict]) -> Dict:
        """AI-powered summarization."""
        if not HAS_OPENAI:
            return self._summarize_with_rules(notes)
        
        # Combine notes content
        combined = "\n\n---\n\n".join([
            f"## {note['date']}\n{note['raw_content'][:2000]}"
            for note in notes
        ])
        
        prompt = """Analyze these daily notes and provide:
1. Key decisions made (most important ones)
2. Lessons learned (worth remembering long-term)
3. Recurring themes or patterns
4. Proposed additions to long-term memory (facts, lessons, preferences discovered)

Format as JSON with keys: key_decisions, lessons_learned, recurring_themes, proposed_memory_additions

Each proposed_memory_addition should have: type (fact/lesson/preference), content, reasoning

Daily Notes:
"""
        
        try:
            response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You analyze daily notes and extract insights for long-term memory. Return valid JSON only."},
                    {"role": "user", "content": prompt + combined[:12000]}
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            result = response.choices[0].message.content
            result = re.sub(r'^```json\s*', '', result)
            result = re.sub(r'\s*```$', '', result)
            summary = json.loads(result)
            summary['period'] = f"{notes[0]['date']} to {notes[-1]['date']}"
            summary['total_days'] = len(notes)
            return summary
        except Exception as e:
            print(f"AI summarization failed: {e}. Falling back to rules.")
            return self._summarize_with_rules(notes)
    
    def to_markdown(self, summary: Dict) -> str:
        """Convert summary to markdown format."""
        lines = [
            f"# Weekly Memory Review\n",
            f"**Period:** {summary['period']}",
            f"**Days Reviewed:** {summary['total_days']}\n",
        ]
        
        if summary.get('key_decisions'):
            lines.append("## Key Decisions\n")
            for decision in summary['key_decisions']:
                lines.append(f"- {decision}")
            lines.append("")
        
        if summary.get('lessons_learned'):
            lines.append("## Lessons Learned\n")
            for lesson in summary['lessons_learned']:
                lines.append(f"- {lesson}")
            lines.append("")
        
        if summary.get('recurring_themes'):
            lines.append("## Recurring Themes\n")
            lines.append(f"Topics that came up frequently: {', '.join(summary['recurring_themes'])}")
            lines.append("")
        
        if summary.get('proposed_memory_additions'):
            lines.append("## Proposed MEMORY.md Additions\n")
            lines.append("Review and add these to your long-term memory:\n")
            for item in summary['proposed_memory_additions']:
                lines.append(f"### {item.get('type', 'Note').title()}")
                lines.append(f"{item.get('content', '')}")
                if item.get('reasoning'):
                    lines.append(f"*Reasoning: {item['reasoning']}*")
                lines.append("")
        
        if summary.get('tasks_summary'):
            ts = summary['tasks_summary']
            lines.append(f"## Task Summary\n")
            lines.append(f"Completed {ts.get('completed', 0)} tasks this period.\n")
        
        return '\n'.join(lines)
    
    def generate_memory_additions(self, summary: Dict) -> str:
        """Generate markdown text to append to MEMORY.md."""
        if not summary.get('proposed_memory_additions'):
            return ""
        
        lines = [
            f"\n## Review: {summary['period']}\n",
            f"*Added: {datetime.now().strftime('%Y-%m-%d')}*\n"
        ]
        
        for item in summary['proposed_memory_additions']:
            item_type = item.get('type', 'note')
            content = item.get('content', '')
            
            if item_type == 'lesson':
                lines.append(f"### Lesson: {content[:50]}...")
                lines.append(f"{content}")
            elif item_type == 'decision':
                lines.append(f"- **Decision:** {content}")
            elif item_type == 'preference':
                lines.append(f"- **Preference:** {content}")
            else:
                lines.append(f"- {content}")
        
        return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='Summarize daily notes into long-term memory'
    )
    parser.add_argument('--days', type=int, default=7,
                        help='Number of days to review (default: 7)')
    parser.add_argument('--from', dest='from_date',
                        help='Start date (YYYY-MM-DD)')
    parser.add_argument('--to', dest='to_date',
                        help='End date (YYYY-MM-DD)')
    parser.add_argument('--memory-path', default='memory',
                        help='Path to memory directory')
    parser.add_argument('--use-ai', action='store_true',
                        help='Use AI for smarter summarization')
    parser.add_argument('--dry-run', action='store_true',
                        help='Show what would be added without making changes')
    parser.add_argument('-o', '--output', help='Output summary to file')
    
    args = parser.parse_args()
    
    # Determine date range
    if args.from_date and args.to_date:
        start_date = datetime.strptime(args.from_date, '%Y-%m-%d')
        end_date = datetime.strptime(args.to_date, '%Y-%m-%d')
    else:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=args.days)
    
    # Initialize summarizer
    summarizer = DailySummarizer(
        memory_path=args.memory_path,
        use_ai=args.use_ai
    )
    
    # Find and parse notes
    note_files = summarizer.find_daily_notes(start_date, end_date)
    
    if not note_files:
        print(f"No daily notes found in {args.memory_path} for date range")
        print(f"  Looking for: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        return 1
    
    print(f"Found {len(note_files)} daily notes")
    
    # Parse notes
    parsed_notes = [summarizer.parse_daily_note(f) for f in note_files]
    
    # Summarize
    summary = summarizer.summarize(parsed_notes)
    
    # Output
    markdown = summarizer.to_markdown(summary)
    
    if args.output:
        Path(args.output).write_text(markdown)
        print(f"Wrote summary to {args.output}")
    else:
        print(markdown)
    
    # Show proposed MEMORY.md additions
    if summary.get('proposed_memory_additions'):
        print("\n" + "="*50)
        print("PROPOSED MEMORY.MD ADDITIONS")
        print("="*50)
        additions = summarizer.generate_memory_additions(summary)
        print(additions)
        
        if not args.dry_run:
            print("\nTo add these to MEMORY.md, run without --dry-run")
    
    return 0


if __name__ == '__main__':
    exit(main())
